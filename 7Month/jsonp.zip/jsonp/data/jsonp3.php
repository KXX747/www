<?php

    // $a = "hello";
    $a = array("name"=>"admin");
    $a = json_encode($a);

    echo "fn('".$a."')";
    
?>