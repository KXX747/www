<?php

    echo "function fn(){
        console.log('hello php')
    }";

?>